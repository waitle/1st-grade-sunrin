#include <stdio.h>
 
int main (void)
{
    int num;
    int result=0;
    for (num=1;num<=10;num++)
    {
               result += num;
			  if(result>10) break;
	}
	printf("%d%d\n", num, result);
    return 0;
}         