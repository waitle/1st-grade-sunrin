#include <stdio.h>
int main(void)
{
	int i, num;
	printf("*********************\n");
	for (i=0;i<16;i++)
		{
			printf("*                   *\n");
		}
	printf("*********************\n");
		return 0;
}