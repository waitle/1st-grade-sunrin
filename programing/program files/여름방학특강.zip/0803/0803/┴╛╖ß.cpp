#include <stdio.h>
 int main (void)
{
	char in=0;
	
	for (in=0;;)
	{
		printf("�Է��ϼ���\n");
	
	    scanf("%c", &in);
		if(in=='q')
		{
			break;
			
		}
		else if (in>='a')
		{
			printf("%c\n", in-32);
			continue;
		}
		else
		{
			printf("%c\n", in+32);
			continue;
		}
	}
	return 0;
}