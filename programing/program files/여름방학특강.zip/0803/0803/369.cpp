#include <stdio.h>
 
int main (void)
{
	double num; 
		double result=0;
	for (num=1;num<=50.0;num++)
	{
		result = result + 1.0/num;
	}
	printf("%f\n", result);
}