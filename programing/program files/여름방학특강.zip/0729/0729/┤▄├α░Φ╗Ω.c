#include <stdio.h>

int main (void)
{
	int a=5, c=10, z;

	z=(a+=2) || (c+=1);

	printf(" a=%d, c=%d\n", a, c);
	printf("z=%d\n", z);
	return 0;
}