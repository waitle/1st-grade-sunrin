#include <string.h>
#include <stdio.h>
int main(int argc, char* argv[])
{
char buffer[200];
strcpy(argv[0], buffer);
printf("Hello %s",buffer);
}