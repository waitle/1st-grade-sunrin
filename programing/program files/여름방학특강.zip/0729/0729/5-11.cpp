#include <stdio.h>

int main (void)
{
	char ch;
	printf("���ڸ� �Է��Ͻÿ�");
	scanf("%c", &ch);
	if(64<ch<96)
	{
		printf("%c", ch+32);
	}
	else if(96<ch<122)
	{
		printf("%c", ch-32);
	}
	return 0;
}