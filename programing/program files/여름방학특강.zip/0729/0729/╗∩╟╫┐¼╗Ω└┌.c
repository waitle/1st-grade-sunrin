#include <stdio.h>

int main (void)

{
	int num=0, a=0, c=0;
	scanf("%d%d", &a, &c);
	num=(a>c)?a:c;
	printf("%d", num);
	return 0;
}