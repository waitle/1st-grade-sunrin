#include <stdio.h>
int main (void)
{
	char o, x;
	scanf("%c%c",&o, &x);
	printf("%d,%d", o, x);
	return 0;
}