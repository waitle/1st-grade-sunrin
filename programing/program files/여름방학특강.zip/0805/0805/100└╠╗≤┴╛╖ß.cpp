#include <stdio.h>

int main(void)
{
	int num1, num2=0;
	for(num1=1;num1<=100;num1++)
	{
		num2 += num1;
		if(num2>=100)
		{
			break;
		}
	}
		printf("%d", num1);

}