#include <stdio.h>

int main(void)
{
	int num1, num2=0;
	for(num1=1;num1<=100;num1++)
	{
		if(num1%5==0)
		{
			num2 += 1;
		}
	}
		printf("%d", num2);

}