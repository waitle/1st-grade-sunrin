#include <stdio.h>

int main(void)
{
	int num1, num2, num3=0;
	printf("�����Է�");
	scanf("%d", &num1);
	for(;;)
	{
		num2=num1%10;
		num3+=num2;	
		num1 = num1/10;
			if(num1==0)
			{
				break;
			}
	}
	printf("%d", num3);
	return 0;
}