#include <stdio.h>
   
int main (void)
{
    int y, m, sum=0;
    for(y=1;y<=20;y++)
    {
        for(m=1;m<=12;m++)
        {
            sum += 12;
        }
    }
	printf("%d", sum);
}