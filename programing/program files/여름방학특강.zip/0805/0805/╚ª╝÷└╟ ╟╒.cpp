#include <stdio.h>

int main(void)
{
	int num1, num2=0;
	for(num1=1;num1<=50;num1++)
	{
		if(num1%2==1)
		{
			num2 += num1;
		}
	}
		printf("%d", num2);

}