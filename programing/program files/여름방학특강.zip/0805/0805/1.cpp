#include <stdio.h>

int main(void)
{
	int num1, num2;
	printf("�����Է�");
	scanf("%d", &num1);
	for(;;)
	{
		num2=num1%10;
			printf("%d", num2);
		num1 = num1/10;
			if(num1==0)
			{
				break;
			}
	}
	return 0;
}