#include <stdio.h>

int main (void)
{
	char num;
	printf("������ �Է��Ͻÿ�");
	scanf("%c", &num);
	switch(num)
	{	
		case 65:
			printf("excellent");
			break;
		
		case 66:
			printf("good");
			break;
		
		case 67:
			printf("poor");
			break;
		
		case 68:
			printf("fail");
			break;
		
		default:
			printf("error");
			break;
	}
}